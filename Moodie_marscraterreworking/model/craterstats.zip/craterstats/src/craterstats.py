#!/usr/bin/env python

import craterstats.cli as cli

cli.main(None)
