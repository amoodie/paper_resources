#  Copyright (c) 2021, Greg Michael
#  Licensed under BSD 3-Clause License. See LICENSE.txt for details.

import os.path

def file_exists(f):
    return os.path.isfile(f) 
