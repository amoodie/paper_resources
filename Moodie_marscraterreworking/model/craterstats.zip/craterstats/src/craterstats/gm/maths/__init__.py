#  Copyright (c) 2021, Greg Michael
#  Licensed under BSD 3-Clause License. See LICENSE.txt for details.

from .normal import normal
from .poisson import poisson
from .range import range,mag
from .poly import poly
from .scl import scl
