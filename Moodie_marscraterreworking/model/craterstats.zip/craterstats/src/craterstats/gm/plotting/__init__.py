#  Copyright (c) 2021, Greg Michael
#  Licensed under BSD 3-Clause License. See LICENSE.txt for details.

from .ticks import ticks
from .mpl_check_font import mpl_check_font
